 <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">Let's Get In Touch!</h2>
                    <hr class="primary">
                    <p>For your complains our customer service attendants are available to attend to you</p>
                </div>
                <div class="col-lg-4 col-lg-offset-2 text-center">
                    <i class="fa fa-envelope-o fa-3x sr-contact"></i>
                    <p><a href="mailto:support.MATRIXFUND@gmail.com">admin@matrixfundonline.com</a></p>
                </div>
                <div class="col-lg-4 text-center">
                    <i class="fa fa-envelope-o fa-3x sr-contact"></i>
                    <p><a href="mailto:support@MATRIXFUND.com">support@matrixfundonline.com</a></p>
                </div>
                <div class="col-lg-4 text-center">
                    <i class="fa fa-facebook fa-3x sr-contact"></i>
                    <p><a href="https://www.facebook.com/mymatrixfund/">matrix fund</a></p>
                </div>
            </div>
        </div>