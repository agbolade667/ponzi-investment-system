<?php

//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

require_once('./Connections/MMM.php');
mysql_select_db($database_MMM, $MMM);

$email = $_POST['memberid'];
$package = $_POST['status'];

  
$query = "SELECT * FROM register WHERE Email = '$email' " or die("error");
//mysql_select_db('register');

$sql = mysql_query($query) or die("You are logged out");

 while($row = mysql_fetch_array($sql)) {
	 	 
	 $id  = $row[0]; 	
	 $Fullnames = $row[1];  	
	 $Username = $row[2];  	
	 $Phone = $row[3];  	
	 $Email = $row[4];  	
	 $Password = $row[5];  	
	 $Bank = $row[6];  	
	 $Account = $row[7];  	
	 $Matched = $row[8];  	
	 $ReceiveMoney = $row[9];  	
	 $Package =  $row[10]; 
	 $Status =  $row[11]; 
	 }
	 
	 $amount = '';
	 
	 if($package == "starter")
	 {
		 $amount = 'N25,000'; 
		 include("starter.php");
	 }
	 
	 else
		 if($package == "bronze")
			 {
				$amount = 'N50,000';
				 include("bronze.php");
			 }
	 else
		if($package == "gold")
			 {
				$amount = 'N100,000'; 
				 include("gold.php");
			 }
	 else
		 if($package == "diamond")
			 {
				$amount = 'N200,000'; 
				 include("diamond.php");
			 }
	  
	 echo "Hello " .$Username. " your id is " .$id;
	 	
	 
	 $query = "UPDATE register SET Status = 'You have been merged to $bronze_Fullnames. <br/> Please pay $amount to: <br/>
Account name: $bronze_Fullnames <br/>
Bank name: $bronze_Bank <br/>
Account Number:  $bronze_Account' 
	 
	 WHERE Email = '$email' ";
	 $sql = mysql_query($query);
	 
	$query2 = "UPDATE register SET Package = '$package'  WHERE Email = '$email' ";
	$sql2 = mysql_query($query2);

	header('Location: ./dashboard.php');

?>